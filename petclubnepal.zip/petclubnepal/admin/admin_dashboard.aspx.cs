﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_adminTesting : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void b1_Click(object sender, EventArgs e)
    {
        Response.Redirect("/admin/adddogdetail.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("/admin/display_order.aspx");
    }
}