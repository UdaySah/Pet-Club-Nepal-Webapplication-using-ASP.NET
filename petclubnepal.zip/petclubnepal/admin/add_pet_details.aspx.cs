﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class admin_dog_details : System.Web.UI.Page
{
//this is Statement connect the database
    string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\petclubnepal\petclubnepal\petclubnepal\App_Data\shopping.mdf;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateGridView();
        }
    }
    void PopulateGridView()
    {
        DataTable dtbl = new DataTable();
        using (SqlConnection sqlCon = new SqlConnection(connectionString))
        {
            sqlCon.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("select * from product", sqlCon);
            sqlDa.Fill(dtbl);

        }
//to check whether pet data are store or not 
        if (dtbl.Rows.Count > 0)
        {
            dog_details.DataSource = dtbl;
            dog_details.DataBind();
        }
        else
        {
            dtbl.Rows.Add(dtbl.NewRow());
            dog_details.DataSource = dtbl;
            dog_details.DataBind();
            dog_details.Rows[0].Cells.Clear();
            dog_details.Rows[0].Cells.Add(new TableCell());
            dog_details.Rows[0].Cells[0].ColumnSpan = dtbl.Columns.Count;
            dog_details.Rows[0].Cells[0].Text = "No Data Found..!";
            dog_details.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
        }
    }
//insert pet details in product database table  through GridView 
//this function conduct by add_pet_details.aspx.cs of admin 
    protected void dog_details_RowCommand(object sender, GridViewCommandEventArgs e)
    {
      
        try
        {
            if (e.CommandName.Equals("AddNew"))
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();

                    string query = "INSERT INTO product(product_name,product_gender,product_quantity,product_price,product_desc,product_image) VALUES (@product_name,@product_gender,@product_quantity,@product_price,@product_desc,@product_image)";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    sqlCmd.Parameters.AddWithValue("@product_name", (dog_details.FooterRow.FindControl("t1footer") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@product_gender", (dog_details.FooterRow.FindControl("t2footer") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@product_quantity", (dog_details.FooterRow.FindControl("t3footer") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@product_price", (dog_details.FooterRow.FindControl("t4footer") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@product_desc", (dog_details.FooterRow.FindControl("t5footer") as TextBox).Text.Trim());
                    FileUpload fu = dog_details.FooterRow.FindControl("f1footer") as FileUpload;
                    String filename = fu.FileName;
                    sqlCmd.Parameters.AddWithValue("@product_image", filename);
                    fu.SaveAs(Request.PhysicalApplicationPath + "./image/" + filename);

                    sqlCmd.ExecuteNonQuery();
                    PopulateGridView();
                    lblSuccessMessage.Text = "new record added.";
                    lblErrorMessage.Text = "";
                }
            }
        }
        catch (Exception ex)
        {
            lblSuccessMessage.Text = "";
            lblErrorMessage.Text = "ex.Message";
        }
    }

//to conduct the edit function
    protected void dog_details_RowEditing(object sender, GridViewEditEventArgs e)
    {
        dog_details.EditIndex = e.NewEditIndex;
        PopulateGridView();
    }

 //to conduct the cancel function inside the edit function
    protected void dog_details_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        dog_details.EditIndex = -1;
        PopulateGridView();
    }

//to conduct the update function inside the edit function
    protected void dog_details_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();

                string query = "UPDATE  product SET product_name='@product_name', product_gender='@product_gender', product_quantity='@product_quantity', product_price='@product_price', product_desc='@product_desc', product_image='@product_image'  WHERE id='@id'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@product_name", (dog_details.Rows[e.RowIndex].FindControl("t1") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@product_gender", (dog_details.Rows[e.RowIndex].FindControl("t2") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@product_quantity", (dog_details.Rows[e.RowIndex].FindControl("t3") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@product_price", (dog_details.Rows[e.RowIndex].FindControl("t4") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@product_desc", (dog_details.Rows[e.RowIndex].FindControl("t5") as TextBox).Text.Trim());
                FileUpload fu = dog_details.FooterRow.FindControl("f1") as FileUpload;
                String filename = fu.FileName;
                sqlCmd.Parameters.AddWithValue("@product_image", filename);
                fu.SaveAs(Request.PhysicalApplicationPath + "./image/" + filename);
                sqlCmd.Parameters.AddWithValue("@id", Convert.ToInt32(dog_details.DataKeys[e.RowIndex].Value.ToString()));
                sqlCmd.ExecuteNonQuery();
                dog_details.EditIndex = -1;
                PopulateGridView();
                lblSuccessMessage.Text = "select record updated.";
                lblErrorMessage.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblSuccessMessage.Text = "";
            lblErrorMessage.Text = "ex.Message";
        }
    }

//to delete pet detail data from product table
    protected void dog_details_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();

                string query = "DELETE FROM product WHERE id=@id ";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@id", Convert.ToInt32(dog_details.DataKeys[e.RowIndex].Value.ToString()));
                sqlCmd.ExecuteNonQuery();
                PopulateGridView();
                lblSuccessMessage.Text = "delete record.";
                lblErrorMessage.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblSuccessMessage.Text = "";
            lblErrorMessage.Text = "ex.Message";
        }
    }

    protected void dog_details_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}

public class AutoFitColumn
{
}