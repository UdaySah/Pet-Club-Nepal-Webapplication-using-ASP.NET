﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


public partial class user_dislay_item : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\petclubnepal\petclubnepal\petclubnepal\App_Data\shopping.mdf;Integrated Security=True");
    int id;
    string product_name, product_gender, product_quantity, product_price, product_desc, product_image;
    protected void Page_Load(object sender, EventArgs e)
    {


        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from product";

        if (Request.QueryString["search"] != null)
        {
            cmd.CommandText = "select * from product where product_name like('%"+Request.QueryString["search"].ToString()+"%')";
        }

        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        d1.DataSource = dt;
        d1.DataBind();
        con.Close();
    }
    

}