﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class user_login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\petclubnepal\petclubnepal\petclubnepal\App_Data\shopping.mdf;Integrated Security=True");
    int tot = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //for remember me-start code
        if(!IsPostBack)
        { 
        if (Request.Cookies["email"] != null && Request.Cookies["password"] != null)
        {
            TextBox1.Text = Request.Cookies["email"].Value;
            TextBox2.Attributes["value"] = Request.Cookies["password"].Value;
        }
    }
        //for remember me-end code
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from registration where email='" + TextBox1.Text + "' and password='" + TextBox2.Text + "' ";
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        tot = Convert.ToInt32(dt.Rows.Count.ToString());
        

        if (tot > 0)
        {
            //for remember me-start code
            if (ChkMe.Checked)
            {
                Response.Cookies["email"].Value = TextBox1.Text;
                Response.Cookies["password"].Value = TextBox2.Text;
                Response.Cookies["email"].Expires = DateTime.Now.AddMinutes(1);
                Response.Cookies["password"].Expires = DateTime.Now.AddMinutes(1);
            }
            else {
                Response.Cookies["email"].Expires = DateTime.Now.AddMinutes(-1);
                Response.Cookies["email"].Expires = DateTime.Now.AddMinutes(-1);
            }

            //for remember me-end code
            if ("admin@gmail.com" == TextBox1.Text)
            {
                
                Session["user"] = TextBox1.Text;
               Response.Redirect("/admin/admin_dashboard.aspx");
            }
            if (Session["orderbutton"] == "yes")
            {
               
                Session["user"] = TextBox1.Text;
                Response.Redirect("update_order_details.aspx");


            }
            else if (Request.Cookies["aa"] == null)
            {
                Session["user"] = TextBox1.Text;
                


            }
            else
            {
                Session["user"] = TextBox1.Text;
                Response.Redirect("order_details.aspx");
            }
            
        }
        else
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('invalid username and password.'); </script>");
        }
        con.Close();
    }
}